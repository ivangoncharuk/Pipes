// LoggerClient.c
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PIPE_NAME "\\\\.\\pipe\\LoggerPipe"
#define BUFFER_SIZE 512

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: LoggerClient.exe \"Your log message here\"\n");
        return 1;
    }

    // Combine all command-line arguments into a single log message.
    char message[BUFFER_SIZE] = {0};
    for (int i = 1; i < argc; i++) {
        strcat(message, argv[i]);
        if (i < argc - 1)
            strcat(message, " ");
    }

    // Connect to the named pipe created by the server.
    HANDLE hPipe = CreateFile(
        PIPE_NAME,          // Pipe name
        GENERIC_WRITE,      // Write access
        0,                  // No sharing
        NULL,               // Default security attributes
        OPEN_EXISTING,      // Opens existing pipe
        0,                  // Default attributes
        NULL);              // No template file

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("Error connecting to pipe. Is the Logger Server running? Error code: %d\n", GetLastError());
        return 1;
    }

    DWORD bytesWritten;
    BOOL success = WriteFile(
        hPipe,                  // Handle to pipe
        message,                // Message to write
        (DWORD) (strlen(message) + 1), // Include the terminating null character
        &bytesWritten,          // Number of bytes written
        NULL);                  // Not using overlapped I/O

    if (!success) {
        printf("Failed to write to pipe. Error code: %d\n", GetLastError());
    } else {
        printf("Message sent: %s\n", message);
    }

    // Clean up.
    CloseHandle(hPipe);
    return 0;
}
