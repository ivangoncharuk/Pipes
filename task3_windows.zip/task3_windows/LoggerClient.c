// LoggerClient.c (Windows Version)
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PIPE_NAME "\\\\.\\pipe\\LoggerPipe" // path to the named pipe - same as server
#define BUFFER_SIZE 512           // buffer size for messages

// Helper function to construct the log message from command line arguments
char* constructMessage(int argc, char* argv[]) {
    char *message = malloc(BUFFER_SIZE); // allocate memory for the message
    if (!message) {
        printf("Failed to allocate memory for message.\n");
        exit(1); // exit if memory allocation fails
    }
    message[0] = '\0'; // initialize as empty string

    // combine all command-line arguments into a single log message
    for (int i = 1; i < argc; i++) {
        strcat(message, argv[i]); // append the argument
        if (i < argc - 1) {
            strcat(message, " "); // add space if not last argument
        }
    }
    return message; // return the constructed message
}

// Helper function to send the message to the named pipe
void sendMessageToPipe(const char* message) {
    // connect to the named pipe created by the server
    HANDLE hPipe = CreateFile(
        PIPE_NAME,      // pipe name
        GENERIC_WRITE,  // write access
        0,              // no sharing
        NULL,           // default security attributes
        OPEN_EXISTING,  // opens existing pipe
        0,              // default attributes
        NULL);          // no template file

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("Error connecting to pipe. Is the Logger Server running? Error code: %d\n", GetLastError());
        exit(1); // exit if cannot connect to pipe
    }

    DWORD bytesWritten;
    BOOL success = WriteFile(
        hPipe,                      // handle to pipe
        message,                    // message to write
        (DWORD) (strlen(message) + 1), // include null terminator
        &bytesWritten,              // number of bytes written
        NULL);                      // not using overlapped i/o

    if (!success) {
        printf("Failed to write to pipe. Error code: %d\n", GetLastError());
    } else {
        printf("Message sent: %s\n", message); // confirmation message
    }

    // clean up - close the pipe handle
    CloseHandle(hPipe);
}

int main(int argc, char* argv[]) {
    // check if a log message is provided as a command-line argument
    if (argc < 2) {
        printf("Usage: LoggerClient.exe \"Your log message here\"\n");
        return 1; // indicate incorrect usage
    }

    // construct the full log message from command line arguments
    char* message = constructMessage(argc, argv);

    // send the constructed message to the logger server via the named pipe
    sendMessageToPipe(message);

    free(message); // free the allocated message memory
    return 0;       // client exits successfully
}