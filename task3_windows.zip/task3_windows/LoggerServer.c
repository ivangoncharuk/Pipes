// LoggerServer.c
#include <windows.h>
#include <stdio.h>
#include <time.h>

#define PIPE_NAME "\\\\.\\pipe\\LoggerPipe"
#define BUFFER_SIZE 512

int main(void) {
    HANDLE hPipe;
    char buffer[BUFFER_SIZE];
    DWORD bytesRead;
    BOOL connected;

    // Create a named pipe for inbound communication.
    hPipe = CreateNamedPipe(
        PIPE_NAME,                          // Pipe name
        PIPE_ACCESS_INBOUND,                // Read-only access
        PIPE_TYPE_MESSAGE |                 // Message-type pipe
        PIPE_READMODE_MESSAGE |             // Message-read mode
        PIPE_WAIT,                          // Blocking mode
        PIPE_UNLIMITED_INSTANCES,           // Max instances
        BUFFER_SIZE,                        // Output buffer size (not used)
        BUFFER_SIZE,                        // Input buffer size
        0,                                  // Default timeout
        NULL);                              // Default security attributes

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("Error creating pipe. Error code: %d\n", GetLastError());
        return 1;
    }
    printf("Logger Server started. Waiting for client connections...\n");

    // Open log file for appending log messages.
    FILE *logFile = fopen("log.txt", "a");
    if (!logFile) {
        printf("Error opening log.txt for writing.\n");
        CloseHandle(hPipe);
        return 1;
    }

    while (1) {
        // Wait for a client to connect to the pipe.
        connected = ConnectNamedPipe(hPipe, NULL) ? TRUE : (GetLastError() == ERROR_PIPE_CONNECTED);
        if (connected) {
            // Clear the buffer and read from the pipe.
            ZeroMemory(buffer, sizeof(buffer));
            if (ReadFile(hPipe, buffer, BUFFER_SIZE, &bytesRead, NULL)) {
                // Get current time for timestamp.
                time_t now = time(NULL);
                struct tm *timeInfo = localtime(&now);
                char timeStr[64];
                strftime(timeStr, sizeof(timeStr), "[%Y-%m-%d %H:%M:%S]", timeInfo);

                // Format the log entry.
                char logEntry[BUFFER_SIZE + 128];
                sprintf(logEntry, "%s %s\n", timeStr, buffer);

                // Append the log entry to log.txt.
                fprintf(logFile, "%s", logEntry);
                fflush(logFile);

                // Print the log entry to the console.
                printf("Logged: %s", logEntry);
            } else {
                printf("Error reading from pipe. Error code: %d\n", GetLastError());
            }
            // Disconnect the pipe to wait for a new client connection.
            DisconnectNamedPipe(hPipe);
        } else {
            printf("Failed to connect to the pipe. Error code: %d\n", GetLastError());
        }
    }

    // Clean up (should be unreachable though)
    fclose(logFile);
    CloseHandle(hPipe);
    return 0;
}
