// LoggerServer.c (Windows Version)
#include <windows.h>
#include <stdio.h>
#include <time.h>

#define PIPE_NAME "\\\\.\\pipe\\LoggerPipe" // path for the named pipe on Windows
#define BUFFER_SIZE 512           // size of the buffer for messages

// Helper function to setup the named pipe
HANDLE setupNamedPipe() {
    // create a named pipe for inbound communication
    HANDLE hPipe = CreateNamedPipe(
        PIPE_NAME,                  // pipe name
        PIPE_ACCESS_INBOUND,        // read-only access for server (inbound)
        PIPE_TYPE_MESSAGE |         // message-type pipe
        PIPE_READMODE_MESSAGE |     // message-read mode
        PIPE_WAIT,                  // blocking mode
        PIPE_UNLIMITED_INSTANCES,   // max instances
        BUFFER_SIZE,                // output buffer size (not used for inbound)
        BUFFER_SIZE,                // input buffer size
        0,                          // default timeout
        NULL);                      // default security attributes

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("Error creating pipe. Error code: %d\n", GetLastError());
        exit(1); // exit on pipe creation failure
    }
    return hPipe; // return the pipe handle
}

// Helper function to open the log file
FILE* openLogFile() {
    // open log file for appending log messages
    FILE *logFile = fopen("log.txt", "a");
    if (!logFile) {
        printf("Error opening log.txt for writing.\n");
        return NULL; // return null if file open fails
    }
    return logFile; // return the log file handle
}

// Helper function to write a log entry to the log file and console
void writeLogEntry(FILE *logFile, const char *buffer) {
    // get current timestamp
    time_t now = time(NULL);
    struct tm *timeInfo = localtime(&now);
    char timeStr[64];
    strftime(timeStr, sizeof(timeStr), "[%Y-%m-%d %H:%M:%S]", timeInfo);

    // format the log entry
    char logEntry[BUFFER_SIZE + 128];
    sprintf(logEntry, "%s %s\n", timeStr, buffer);

    // append the log entry to log.txt
    fprintf(logFile, "%s", logEntry);
    fflush(logFile); // flush to ensure immediate write

    // print the log entry to the console
    printf("Logged: %s", logEntry);
}

// Helper function to handle a client connection
void handleClientConnection(HANDLE hPipe, FILE *logFile) {
    char buffer[BUFFER_SIZE];
    DWORD bytesRead;
    BOOL connected;

    // wait for a client to connect to the pipe
    connected = ConnectNamedPipe(hPipe, NULL) ? TRUE : (GetLastError() == ERROR_PIPE_CONNECTED);
    if (connected) {
        // clear the buffer and read from the pipe
        ZeroMemory(buffer, sizeof(buffer));
        if (ReadFile(hPipe, buffer, BUFFER_SIZE, &bytesRead, NULL)) {
            writeLogEntry(logFile, buffer); // write the received message as a log entry
        } else {
            printf("Error reading from pipe. Error code: %d\n", GetLastError());
        }
        // disconnect the pipe to wait for a new client connection
        DisconnectNamedPipe(hPipe);
    } else {
        printf("Failed to connect to the pipe. Error code: %d\n", GetLastError());
    }
}

// Main function - server loop
int main(void) {
    HANDLE hPipe = setupNamedPipe(); // setup the named pipe
    if (hPipe == NULL) return 1;     // exit if pipe setup failed

    FILE *logFile = openLogFile();   // open the log file
    if (logFile == NULL) {
        CloseHandle(hPipe); // close pipe handle before exiting
        return 1;           // exit if log file open failed
    }

    printf("Logger Server started. Waiting for client connections...\n");

    while (1) { // main server loop - runs forever
        handleClientConnection(hPipe, logFile); // handle client connections
    }

    // clean up (unreachable in infinite loop, but good practice)
    fclose(logFile);
    CloseHandle(hPipe);
    return 0; // success (unreachable)
}